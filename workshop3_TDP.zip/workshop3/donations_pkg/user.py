def login(database, username, password):
    if username in database:
        if password == database[username]:
            print("Welcome to DonateMe,", username)
            return username
        elif password != database[username]:
            print("Password does not match username.")
            return ""
    else:
        print("Username not found. Please register.")
        return ""

def register(database, username):
    if username in database:
        print("Username already registered.")
        return ""
    else:
        print("Username has been registered.")
        return username