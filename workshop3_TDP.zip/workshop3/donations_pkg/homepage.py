from functools import total_ordering


def show_homepage():
    print("""
            === DonateMe Homepage ===          
    ---------------------------------------------------
    | 1.    Login        | 2.    Register             |
    ---------------------------------------------------
    ---------------------------------------------------
    | 3.    Donate       | 4.    Show Donations       |
    ---------------------------------------------------
    ---------------------------------------------------
    |               5. Exit                           |
    ---------------------------------------------------
    """)

def donate(username):
    donation_amt = input("Enter amount to donate: ")
    donation_amt = float(donation_amt)
    donation = (username + " donated $" + str(donation_amt))
    
    # total_donation = 0
    # total_donation += donation_amt
    # print(donation_amt)
    # print(total_donation)
    
    return donation

def show_donation(donations):
    print("\n--- All Donations ---")
    
    if donations == []:
        print("Currently, there are no donations.")
    else:
        #total_donation = 0
        
        for item in donations:
            print(item)
        #print("Total = $", total_donation)
        