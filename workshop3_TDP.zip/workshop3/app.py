from donations_pkg.homepage import show_homepage, donate, show_donation
from donations_pkg.user import login, register

database = {"admin": "password123"}
donations = []
authorized_user = ""


show_homepage()
if authorized_user == "":
    print("You must be logged in to donate.")
else:
    print("Logged in as:", authorized_user)


while True:
    show_homepage()
    user_select = input("Select an option: ")
    
    if user_select == "1":
        username = input("Enter username: ")
        password = input("Enter password: ")
        authorized_user = login(database, username, password)
    
    elif user_select == "2":
        username = input("Enter username: ")
        password = input("Enter password: ")
        authorized_user = register(database, username)
        if authorized_user != "":
            database[username] = password
    
    elif user_select == "3":
        if authorized_user == "":
            print("You are not logged in.")
        else:
            donation = donate(authorized_user)
            donations.append(donation)

    elif user_select == "4":
        show_donation(donations)
   
    elif user_select == "5":
        print("You have exited the program. Goodbye!")
        break
    
    else:
        print("Please select an option between 1-5")

